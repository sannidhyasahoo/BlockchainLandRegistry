# Liquid Effect

A Pen created on CodePen.

Original URL: [https://codepen.io/soju22/pen/myVWBGa](https://codepen.io/soju22/pen/myVWBGa).

Yet another liquid effect made with ThreeJS / WebGL 🌊
First time I tried this effect was in 1999 with a java applet, I feel old 😅